from wing_eda.eda_sizov.main import BaseEda
from wing_eda.eda_sizov.report import Report
