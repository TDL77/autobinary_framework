from .binning_2d import OptimalBinning2D


__all__ = ['OptimalBinning2D']
